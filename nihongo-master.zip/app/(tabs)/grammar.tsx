import { useState } from "react";
import {
  View,
  Text,
  Pressable,
  FlatList,
  StyleSheet,
  TextInput,
} from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { getGrammarByLevel, GrammarItem } from "@/data/grammar";
import { useProgress } from "@/hooks/use-progress";
import { IconSymbol } from "@/components/ui/icon-symbol";

const LEVEL_COLORS = { N3: "#27AE60", N2: "#E67E22", N1: "#C0392B" };

export default function GrammarScreen() {
  const colors = useColors();
  const { progress } = useProgress();
  const [selectedLevel, setSelectedLevel] = useState<"N3" | "N2" | "N1">(progress.selectedLevel);
  const [search, setSearch] = useState("");
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const grammar = getGrammarByLevel(selectedLevel);
  const filtered = grammar.filter(
    (g) =>
      g.pattern.includes(search) ||
      g.meaning.includes(search) ||
      g.category.includes(search)
  );

  const renderItem = ({ item }: { item: GrammarItem }) => {
    const isExpanded = expandedId === item.id;
    return (
      <Pressable
        style={({ pressed }) => [
          styles.grammarCard,
          { backgroundColor: colors.surface, borderColor: colors.border },
          isExpanded && { borderColor: LEVEL_COLORS[selectedLevel] + "80" },
          pressed && { opacity: 0.9 },
        ]}
        onPress={() => setExpandedId(isExpanded ? null : item.id)}
      >
        <View style={styles.cardHeader}>
          <View style={styles.cardHeaderLeft}>
            <View style={[styles.levelDot, { backgroundColor: LEVEL_COLORS[selectedLevel] }]} />
            <Text style={[styles.patternText, { color: colors.primary }]}>{item.pattern}</Text>
          </View>
          <View style={styles.cardHeaderRight}>
            <View style={[styles.categoryBadge, { backgroundColor: colors.border }]}>
              <Text style={[styles.categoryText, { color: colors.muted }]}>{item.category}</Text>
            </View>
            <IconSymbol
              name={isExpanded ? "chevron.left" : "chevron.right"}
              size={16}
              color={colors.muted}
              style={{ transform: [{ rotate: isExpanded ? "90deg" : "0deg" }] }}
            />
          </View>
        </View>
        <Text style={[styles.meaningText, { color: colors.foreground }]}>{item.meaning}</Text>
        <Text style={[styles.usageText, { color: colors.muted }]}>{item.usage}</Text>

        {isExpanded && (
          <View style={[styles.examplesBox, { borderTopColor: colors.border }]}>
            <Text style={[styles.examplesTitle, { color: colors.muted }]}>ตัวอย่าง</Text>
            {item.examples.map((ex, i) => (
              <View key={i} style={[styles.exampleItem, { backgroundColor: colors.background }]}>
                <Text style={[styles.exampleJP, { color: colors.foreground }]}>{ex.jp}</Text>
                <Text style={[styles.exampleTH, { color: colors.muted }]}>{ex.th}</Text>
              </View>
            ))}
          </View>
        )}
      </Pressable>
    );
  };

  return (
    <ScreenContainer>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>ไวยากรณ์</Text>
        <View style={styles.levelTabs}>
          {(["N3", "N2", "N1"] as const).map((lv) => (
            <Pressable
              key={lv}
              style={({ pressed }) => [
                styles.levelTab,
                { borderColor: LEVEL_COLORS[lv] },
                selectedLevel === lv && { backgroundColor: LEVEL_COLORS[lv] },
                pressed && { opacity: 0.8 },
              ]}
              onPress={() => {
                setSelectedLevel(lv);
                setExpandedId(null);
              }}
            >
              <Text style={[styles.levelTabText, { color: selectedLevel === lv ? "#FFF" : LEVEL_COLORS[lv] }]}>
                {lv}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      {/* Search */}
      <View style={[styles.searchBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
        <IconSymbol name="magnifyingglass" size={18} color={colors.muted} />
        <TextInput
          style={[styles.searchInput, { color: colors.foreground }]}
          placeholder="ค้นหาไวยากรณ์..."
          placeholderTextColor={colors.muted}
          value={search}
          onChangeText={setSearch}
          returnKeyType="search"
        />
        {search.length > 0 && (
          <Pressable onPress={() => setSearch("")}>
            <IconSymbol name="xmark.circle.fill" size={18} color={colors.muted} />
          </Pressable>
        )}
      </View>

      <Text style={[styles.countText, { color: colors.muted }]}>
        {filtered.length} รูปแบบ
      </Text>

      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id}
        renderItem={renderItem}
        contentContainerStyle={{ padding: 12, paddingBottom: 24 }}
        showsVerticalScrollIndicator={false}
        ItemSeparatorComponent={() => <View style={{ height: 10 }} />}
      />
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 0.5,
  },
  headerTitle: { fontSize: 22, fontWeight: "800", marginBottom: 10 },
  levelTabs: { flexDirection: "row", gap: 8 },
  levelTab: {
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 2,
  },
  levelTabText: { fontSize: 13, fontWeight: "700" },
  searchBox: {
    flexDirection: "row",
    alignItems: "center",
    margin: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderRadius: 12,
    borderWidth: 1,
    gap: 8,
  },
  searchInput: { flex: 1, fontSize: 15 },
  countText: { paddingHorizontal: 16, fontSize: 12, marginBottom: 4 },
  grammarCard: {
    padding: 14,
    borderRadius: 14,
    borderWidth: 1,
  },
  cardHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 6,
  },
  cardHeaderLeft: { flexDirection: "row", alignItems: "center", gap: 8, flex: 1 },
  cardHeaderRight: { flexDirection: "row", alignItems: "center", gap: 8 },
  levelDot: { width: 8, height: 8, borderRadius: 4 },
  patternText: { fontSize: 17, fontWeight: "800" },
  categoryBadge: {
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 8,
  },
  categoryText: { fontSize: 11 },
  meaningText: { fontSize: 15, fontWeight: "600", marginBottom: 4 },
  usageText: { fontSize: 12, fontStyle: "italic" },
  examplesBox: {
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 0.5,
    gap: 8,
  },
  examplesTitle: { fontSize: 12, fontWeight: "700", textTransform: "uppercase", letterSpacing: 1, marginBottom: 4 },
  exampleItem: {
    padding: 10,
    borderRadius: 10,
  },
  exampleJP: { fontSize: 14, lineHeight: 20 },
  exampleTH: { fontSize: 12, marginTop: 4, lineHeight: 18 },
});
