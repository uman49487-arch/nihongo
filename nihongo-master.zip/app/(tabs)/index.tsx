import { ScrollView, Text, View, Pressable, StyleSheet } from "react-native";
import { useRouter } from "expo-router";
import * as Haptics from "expo-haptics";
import { Platform } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useProgress } from "@/hooks/use-progress";
import { useColors } from "@/hooks/use-colors";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { vocabularyN3, vocabularyN2, vocabularyN1 } from "@/data/vocabulary";

const LEVEL_COLORS = {
  N3: "#27AE60",
  N2: "#E67E22",
  N1: "#C0392B",
};

const LEVEL_TOTALS = {
  N3: vocabularyN3.length,
  N2: vocabularyN2.length,
  N1: vocabularyN1.length,
};

export default function HomeScreen() {
  const router = useRouter();
  const colors = useColors();
  const { progress, getLearnedCount, getAverageQuizScore } = useProgress();
  const level = progress.selectedLevel;
  const learnedCount = getLearnedCount(level);
  const totalVocab = LEVEL_TOTALS[level];
  const progressPct = totalVocab > 0 ? Math.round((learnedCount / totalVocab) * 100) : 0;
  const avgScore = getAverageQuizScore(level);

  const handleNav = (tab: string) => {
    if (Platform.OS !== "web") {
      Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    }
    router.push(`/(tabs)/${tab}` as any);
  };

  const quickActions = [
    {
      icon: "book.fill" as const,
      label: "เรียนคำศัพท์",
      sublabel: `${learnedCount}/${totalVocab} คำ`,
      color: "#3498DB",
      route: "vocabulary",
    },
    {
      icon: "text.book.closed.fill" as const,
      label: "ไวยากรณ์",
      sublabel: "เรียนรู้รูปแบบ",
      color: "#9B59B6",
      route: "grammar",
    },
    {
      icon: "checkmark.circle.fill" as const,
      label: "แบบทดสอบ",
      sublabel: `คะแนนเฉลี่ย ${avgScore}%`,
      color: "#E67E22",
      route: "quiz",
    },
    {
      icon: "chart.bar.fill" as const,
      label: "ความก้าวหน้า",
      sublabel: `Streak ${progress.streak} วัน`,
      color: "#27AE60",
      route: "progress",
    },
  ];

  return (
    <ScreenContainer>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: 24 }}
      >
        {/* Header */}
        <View style={[styles.header, { backgroundColor: colors.primary }]}>
          <View style={styles.headerContent}>
            <Text style={styles.headerTitle}>日本語マスター</Text>
            <Text style={styles.headerSubtitle}>Nihongo Master</Text>
            <View style={[styles.levelBadge, { backgroundColor: LEVEL_COLORS[level] }]}>
              <Text style={styles.levelBadgeText}>กำลังเรียน {level}</Text>
            </View>
          </View>
          {/* Streak */}
          <View style={styles.streakBox}>
            <IconSymbol name="flame.fill" size={28} color="#F39C12" />
            <Text style={styles.streakNumber}>{progress.streak}</Text>
            <Text style={styles.streakLabel}>วันติดต่อกัน</Text>
          </View>
        </View>

        {/* Progress Bar */}
        <View style={[styles.progressCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <View style={styles.progressHeader}>
            <Text style={[styles.progressTitle, { color: colors.foreground }]}>
              ความก้าวหน้าระดับ {level}
            </Text>
            <Text style={[styles.progressPct, { color: colors.primary }]}>{progressPct}%</Text>
          </View>
          <View style={[styles.progressBarBg, { backgroundColor: colors.border }]}>
            <View
              style={[
                styles.progressBarFill,
                { width: `${progressPct}%` as any, backgroundColor: LEVEL_COLORS[level] },
              ]}
            />
          </View>
          <Text style={[styles.progressSub, { color: colors.muted }]}>
            เรียนแล้ว {learnedCount} จาก {totalVocab} คำ
          </Text>
        </View>

        {/* Quick Actions */}
        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>เมนูหลัก</Text>
        </View>
        <View style={styles.quickGrid}>
          {quickActions.map((action) => (
            <Pressable
              key={action.route}
              style={({ pressed }) => [
                styles.quickCard,
                { backgroundColor: colors.surface, borderColor: colors.border },
                pressed && { opacity: 0.75, transform: [{ scale: 0.97 }] },
              ]}
              onPress={() => handleNav(action.route)}
            >
              <View style={[styles.quickIconBg, { backgroundColor: action.color + "22" }]}>
                <IconSymbol name={action.icon} size={28} color={action.color} />
              </View>
              <Text style={[styles.quickLabel, { color: colors.foreground }]}>{action.label}</Text>
              <Text style={[styles.quickSub, { color: colors.muted }]}>{action.sublabel}</Text>
            </Pressable>
          ))}
        </View>

        {/* Level Selector */}
        <View style={styles.sectionHeader}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>เลือกระดับ</Text>
        </View>
        <View style={styles.levelRow}>
          {(["N3", "N2", "N1"] as const).map((lv) => (
            <Pressable
              key={lv}
              style={({ pressed }) => [
                styles.levelBtn,
                {
                  backgroundColor: level === lv ? LEVEL_COLORS[lv] : colors.surface,
                  borderColor: LEVEL_COLORS[lv],
                },
                pressed && { opacity: 0.8 },
              ]}
              onPress={() => {
                if (Platform.OS !== "web") {
                  Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
                }
              }}
            >
              <Text
                style={[
                  styles.levelBtnText,
                  { color: level === lv ? "#FFFFFF" : LEVEL_COLORS[lv] },
                ]}
              >
                {lv}
              </Text>
              <Text
                style={[
                  styles.levelBtnSub,
                  { color: level === lv ? "#FFFFFF99" : colors.muted },
                ]}
              >
                {lv === "N3" ? "ระดับกลาง" : lv === "N2" ? "ระดับสูง" : "ระดับสูงสุด"}
              </Text>
            </Pressable>
          ))}
        </View>

        {/* Today's Word */}
        <View style={[styles.todayCard, { backgroundColor: colors.primary + "15", borderColor: colors.primary + "40" }]}>
          <Text style={[styles.todayTitle, { color: colors.primary }]}>คำศัพท์วันนี้</Text>
          <Text style={styles.todayKanji}>日本語</Text>
          <Text style={[styles.todayFurigana, { color: colors.muted }]}>にほんご</Text>
          <Text style={[styles.todayMeaning, { color: colors.foreground }]}>ภาษาญี่ปุ่น</Text>
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: 20,
    paddingVertical: 24,
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
  headerContent: { flex: 1 },
  headerTitle: { fontSize: 26, fontWeight: "800", color: "#FFFFFF", letterSpacing: 1 },
  headerSubtitle: { fontSize: 13, color: "#FFFFFF99", marginTop: 2 },
  levelBadge: {
    alignSelf: "flex-start",
    marginTop: 10,
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 20,
  },
  levelBadgeText: { fontSize: 12, fontWeight: "700", color: "#FFFFFF" },
  streakBox: { alignItems: "center", marginLeft: 16 },
  streakNumber: { fontSize: 28, fontWeight: "800", color: "#FFFFFF", marginTop: 2 },
  streakLabel: { fontSize: 11, color: "#FFFFFF99" },
  progressCard: {
    margin: 16,
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
  },
  progressHeader: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  progressTitle: { fontSize: 15, fontWeight: "600" },
  progressPct: { fontSize: 18, fontWeight: "800" },
  progressBarBg: { height: 8, borderRadius: 4, marginTop: 10, overflow: "hidden" },
  progressBarFill: { height: 8, borderRadius: 4 },
  progressSub: { fontSize: 12, marginTop: 6 },
  sectionHeader: { paddingHorizontal: 16, marginBottom: 10, marginTop: 4 },
  sectionTitle: { fontSize: 17, fontWeight: "700" },
  quickGrid: {
    flexDirection: "row",
    flexWrap: "wrap",
    paddingHorizontal: 12,
    gap: 10,
    marginBottom: 8,
  },
  quickCard: {
    width: "47%",
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
    alignItems: "flex-start",
  },
  quickIconBg: {
    width: 48,
    height: 48,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 10,
  },
  quickLabel: { fontSize: 14, fontWeight: "700", marginBottom: 2 },
  quickSub: { fontSize: 12 },
  levelRow: {
    flexDirection: "row",
    paddingHorizontal: 16,
    gap: 10,
    marginBottom: 16,
  },
  levelBtn: {
    flex: 1,
    paddingVertical: 14,
    borderRadius: 14,
    borderWidth: 2,
    alignItems: "center",
  },
  levelBtnText: { fontSize: 18, fontWeight: "800" },
  levelBtnSub: { fontSize: 10, marginTop: 2 },
  todayCard: {
    marginHorizontal: 16,
    padding: 20,
    borderRadius: 16,
    borderWidth: 1,
    alignItems: "center",
  },
  todayTitle: { fontSize: 13, fontWeight: "700", marginBottom: 8, textTransform: "uppercase", letterSpacing: 1 },
  todayKanji: { fontSize: 40, fontWeight: "800", color: "#C0392B" },
  todayFurigana: { fontSize: 14, marginTop: 4 },
  todayMeaning: { fontSize: 18, fontWeight: "600", marginTop: 6 },
});
