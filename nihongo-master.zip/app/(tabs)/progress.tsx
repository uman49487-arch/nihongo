import { View, Text, ScrollView, StyleSheet, Pressable } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useProgress } from "@/hooks/use-progress";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { vocabularyN3, vocabularyN2, vocabularyN1 } from "@/data/vocabulary";
import { grammarN3, grammarN2, grammarN1 } from "@/data/grammar";

const LEVEL_COLORS = { N3: "#27AE60", N2: "#E67E22", N1: "#C0392B" };
const VOCAB_TOTALS = { N3: vocabularyN3.length, N2: vocabularyN2.length, N1: vocabularyN1.length };
const GRAMMAR_TOTALS = { N3: grammarN3.length, N2: grammarN2.length, N1: grammarN1.length };

function ProgressBar({ value, max, color }: { value: number; max: number; color: string }) {
  const pct = max > 0 ? Math.min((value / max) * 100, 100) : 0;
  return (
    <View style={progressStyles.barBg}>
      <View style={[progressStyles.barFill, { width: `${pct}%` as any, backgroundColor: color }]} />
    </View>
  );
}

const progressStyles = StyleSheet.create({
  barBg: { height: 8, borderRadius: 4, backgroundColor: "#E5E7EB", overflow: "hidden" },
  barFill: { height: 8, borderRadius: 4 },
});

export default function ProgressScreen() {
  const colors = useColors();
  const { progress, getLearnedCount, getAverageQuizScore, resetProgress } = useProgress();

  const levels = ["N3", "N2", "N1"] as const;

  // Build last 7 days streak calendar
  const today = new Date();
  const last7Days = Array.from({ length: 7 }, (_, i) => {
    const d = new Date(today);
    d.setDate(today.getDate() - (6 - i));
    return d.toISOString().split("T")[0];
  });

  const studiedDays = new Set([
    progress.lastStudyDate,
    ...progress.n3.quizScores.map((s) => s.date),
    ...progress.n2.quizScores.map((s) => s.date),
    ...progress.n1.quizScores.map((s) => s.date),
  ]);

  const totalLearned =
    getLearnedCount("N3") + getLearnedCount("N2") + getLearnedCount("N1");
  const totalVocab = VOCAB_TOTALS.N3 + VOCAB_TOTALS.N2 + VOCAB_TOTALS.N1;
  const totalQuizzes =
    progress.n3.quizScores.length +
    progress.n2.quizScores.length +
    progress.n1.quizScores.length;

  return (
    <ScreenContainer>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: 32 }}>
        {/* Header */}
        <View style={[styles.header, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
          <Text style={[styles.headerTitle, { color: colors.foreground }]}>ความก้าวหน้า</Text>
        </View>

        {/* Streak */}
        <View style={[styles.streakCard, { backgroundColor: "#C0392B", }]}>
          <IconSymbol name="flame.fill" size={36} color="#F39C12" />
          <View style={styles.streakInfo}>
            <Text style={styles.streakNumber}>{progress.streak}</Text>
            <Text style={styles.streakLabel}>วันติดต่อกัน</Text>
          </View>
          <View style={styles.streakRight}>
            <Text style={styles.streakTotalLabel}>เรียนทั้งหมด</Text>
            <Text style={styles.streakTotalNum}>{totalLearned} คำ</Text>
          </View>
        </View>

        {/* 7-Day Calendar */}
        <View style={[styles.calendarCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>7 วันล่าสุด</Text>
          <View style={styles.calendarRow}>
            {last7Days.map((day) => {
              const studied = studiedDays.has(day);
              const isToday = day === today.toISOString().split("T")[0];
              const dayNum = new Date(day).getDate();
              const dayName = new Date(day).toLocaleDateString("th-TH", { weekday: "short" });
              return (
                <View key={day} style={styles.calendarDay}>
                  <Text style={[styles.calDayName, { color: colors.muted }]}>{dayName}</Text>
                  <View
                    style={[
                      styles.calDot,
                      studied
                        ? { backgroundColor: "#C0392B" }
                        : { backgroundColor: colors.border },
                      isToday && { borderWidth: 2, borderColor: "#F39C12" },
                    ]}
                  >
                    <Text style={[styles.calDayNum, { color: studied ? "#FFF" : colors.muted }]}>
                      {dayNum}
                    </Text>
                  </View>
                </View>
              );
            })}
          </View>
        </View>

        {/* Summary Stats */}
        <View style={styles.statsRow}>
          <View style={[styles.statCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <IconSymbol name="book.fill" size={24} color="#3498DB" />
            <Text style={[styles.statNum, { color: colors.foreground }]}>{totalLearned}</Text>
            <Text style={[styles.statLabel, { color: colors.muted }]}>คำที่เรียนแล้ว</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <IconSymbol name="checkmark.circle.fill" size={24} color="#27AE60" />
            <Text style={[styles.statNum, { color: colors.foreground }]}>{totalQuizzes}</Text>
            <Text style={[styles.statLabel, { color: colors.muted }]}>ครั้งที่ทดสอบ</Text>
          </View>
          <View style={[styles.statCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <IconSymbol name="trophy.fill" size={24} color="#F39C12" />
            <Text style={[styles.statNum, { color: colors.foreground }]}>
              {totalQuizzes > 0
                ? Math.round(
                    (getAverageQuizScore("N3") + getAverageQuizScore("N2") + getAverageQuizScore("N1")) / 3
                  )
                : 0}%
            </Text>
            <Text style={[styles.statLabel, { color: colors.muted }]}>คะแนนเฉลี่ย</Text>
          </View>
        </View>

        {/* Per-Level Progress */}
        <View style={[styles.levelSection, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>ความก้าวหน้าแต่ละระดับ</Text>
          {levels.map((lv) => {
            const learned = getLearnedCount(lv);
            const total = VOCAB_TOTALS[lv];
            const pct = total > 0 ? Math.round((learned / total) * 100) : 0;
            const avgScore = getAverageQuizScore(lv);
            const quizCount = progress[lv.toLowerCase() as "n3" | "n2" | "n1"].quizScores.length;
            return (
              <View key={lv} style={[styles.levelRow, { borderTopColor: colors.border }]}>
                <View style={[styles.levelBadge, { backgroundColor: LEVEL_COLORS[lv] }]}>
                  <Text style={styles.levelBadgeText}>{lv}</Text>
                </View>
                <View style={styles.levelInfo}>
                  <View style={styles.levelInfoRow}>
                    <Text style={[styles.levelInfoLabel, { color: colors.foreground }]}>
                      คำศัพท์: {learned}/{total}
                    </Text>
                    <Text style={[styles.levelInfoPct, { color: LEVEL_COLORS[lv] }]}>{pct}%</Text>
                  </View>
                  <ProgressBar value={learned} max={total} color={LEVEL_COLORS[lv]} />
                  <View style={styles.levelInfoRow}>
                    <Text style={[styles.levelInfoSub, { color: colors.muted }]}>
                      ทดสอบ {quizCount} ครั้ง
                    </Text>
                    <Text style={[styles.levelInfoSub, { color: colors.muted }]}>
                      เฉลี่ย {avgScore}%
                    </Text>
                  </View>
                </View>
              </View>
            );
          })}
        </View>

        {/* Grammar Progress */}
        <View style={[styles.levelSection, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.sectionTitle, { color: colors.foreground }]}>ไวยากรณ์แต่ละระดับ</Text>
          {levels.map((lv) => {
            const total = GRAMMAR_TOTALS[lv];
            return (
              <View key={lv} style={[styles.levelRow, { borderTopColor: colors.border }]}>
                <View style={[styles.levelBadge, { backgroundColor: LEVEL_COLORS[lv] }]}>
                  <Text style={styles.levelBadgeText}>{lv}</Text>
                </View>
                <View style={styles.levelInfo}>
                  <Text style={[styles.levelInfoLabel, { color: colors.foreground }]}>
                    {total} รูปแบบไวยากรณ์
                  </Text>
                  <ProgressBar value={total} max={total} color={LEVEL_COLORS[lv]} />
                </View>
              </View>
            );
          })}
        </View>

        {/* Reset Button */}
        <Pressable
          style={({ pressed }) => [
            styles.resetBtn,
            { borderColor: colors.error },
            pressed && { opacity: 0.7 },
          ]}
          onPress={resetProgress}
        >
          <IconSymbol name="arrow.clockwise" size={18} color={colors.error} />
          <Text style={[styles.resetBtnText, { color: colors.error }]}>รีเซ็ตความก้าวหน้า</Text>
        </Pressable>
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 0.5,
  },
  headerTitle: { fontSize: 22, fontWeight: "800" },
  streakCard: {
    flexDirection: "row",
    alignItems: "center",
    margin: 16,
    padding: 20,
    borderRadius: 20,
    gap: 12,
  },
  streakInfo: { flex: 1 },
  streakNumber: { fontSize: 40, fontWeight: "900", color: "#FFFFFF" },
  streakLabel: { fontSize: 13, color: "#FFFFFF99" },
  streakRight: { alignItems: "flex-end" },
  streakTotalLabel: { fontSize: 12, color: "#FFFFFF99" },
  streakTotalNum: { fontSize: 20, fontWeight: "800", color: "#FFFFFF" },
  calendarCard: {
    marginHorizontal: 16,
    marginBottom: 16,
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
  },
  sectionTitle: { fontSize: 16, fontWeight: "700", marginBottom: 12 },
  calendarRow: { flexDirection: "row", justifyContent: "space-between" },
  calendarDay: { alignItems: "center", gap: 6 },
  calDayName: { fontSize: 11 },
  calDot: {
    width: 36,
    height: 36,
    borderRadius: 18,
    alignItems: "center",
    justifyContent: "center",
  },
  calDayNum: { fontSize: 13, fontWeight: "700" },
  statsRow: {
    flexDirection: "row",
    paddingHorizontal: 16,
    gap: 10,
    marginBottom: 16,
  },
  statCard: {
    flex: 1,
    padding: 14,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: "center",
    gap: 6,
  },
  statNum: { fontSize: 22, fontWeight: "800" },
  statLabel: { fontSize: 11, textAlign: "center" },
  levelSection: {
    marginHorizontal: 16,
    marginBottom: 16,
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
  },
  levelRow: {
    flexDirection: "row",
    alignItems: "center",
    paddingTop: 12,
    marginTop: 12,
    borderTopWidth: 0.5,
    gap: 12,
  },
  levelBadge: {
    width: 44,
    height: 44,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  levelBadgeText: { fontSize: 14, fontWeight: "800", color: "#FFFFFF" },
  levelInfo: { flex: 1, gap: 6 },
  levelInfoRow: { flexDirection: "row", justifyContent: "space-between", alignItems: "center" },
  levelInfoLabel: { fontSize: 14, fontWeight: "600" },
  levelInfoPct: { fontSize: 14, fontWeight: "700" },
  levelInfoSub: { fontSize: 11 },
  resetBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    marginHorizontal: 16,
    paddingVertical: 14,
    borderRadius: 14,
    borderWidth: 1.5,
    gap: 8,
  },
  resetBtnText: { fontSize: 15, fontWeight: "600" },
});
