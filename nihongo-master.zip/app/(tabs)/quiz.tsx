import { useState, useCallback } from "react";
import {
  View,
  Text,
  Pressable,
  StyleSheet,
  ScrollView,
} from "react-native";
import * as Haptics from "expo-haptics";
import { Platform } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useProgress } from "@/hooks/use-progress";
import { getVocabByLevel, allVocabulary } from "@/data/vocabulary";
import { IconSymbol } from "@/components/ui/icon-symbol";

const LEVEL_COLORS = { N3: "#27AE60", N2: "#E67E22", N1: "#C0392B" };

type QuizState = "setup" | "playing" | "result";
type QuizQuestion = {
  question: string;
  furigana: string;
  correct: string;
  options: string[];
  explanation: string;
};

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr];
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [a[i], a[j]] = [a[j], a[i]];
  }
  return a;
}

function generateQuiz(level: "N3" | "N2" | "N1", count = 10): QuizQuestion[] {
  const vocab = getVocabByLevel(level);
  const shuffled = shuffle(vocab).slice(0, count);
  const allMeanings = allVocabulary.map((v) => v.meaning);

  return shuffled.map((item) => {
    const wrongOptions = shuffle(
      allMeanings.filter((m) => m !== item.meaning)
    ).slice(0, 3);
    const options = shuffle([item.meaning, ...wrongOptions]);
    return {
      question: item.kanji,
      furigana: item.furigana,
      correct: item.meaning,
      options,
      explanation: `${item.kanji} (${item.furigana}) = ${item.meaning}\n${item.exampleJP}\n${item.exampleTH}`,
    };
  });
}

export default function QuizScreen() {
  const colors = useColors();
  const { progress, addQuizScore } = useProgress();
  const [selectedLevel, setSelectedLevel] = useState<"N3" | "N2" | "N1">(progress.selectedLevel);
  const [quizState, setQuizState] = useState<QuizState>("setup");
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [currentQ, setCurrentQ] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [showExplanation, setShowExplanation] = useState(false);

  const startQuiz = useCallback(() => {
    const qs = generateQuiz(selectedLevel, 10);
    setQuestions(qs);
    setCurrentQ(0);
    setScore(0);
    setSelectedAnswer(null);
    setShowExplanation(false);
    setQuizState("playing");
  }, [selectedLevel]);

  const handleAnswer = (answer: string) => {
    if (selectedAnswer) return;
    setSelectedAnswer(answer);
    setShowExplanation(true);
    const isCorrect = answer === questions[currentQ].correct;
    if (isCorrect) {
      if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
      setScore((s) => s + 1);
    } else {
      if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Error);
    }
  };

  const handleNext = async () => {
    if (currentQ < questions.length - 1) {
      setCurrentQ((q) => q + 1);
      setSelectedAnswer(null);
      setShowExplanation(false);
    } else {
      await addQuizScore(score + (selectedAnswer === questions[currentQ].correct ? 0 : 0), questions.length, selectedLevel);
      setQuizState("result");
    }
  };

  const getOptionStyle = (option: string) => {
    if (!selectedAnswer) return [styles.optionBtn, { backgroundColor: colors.surface, borderColor: colors.border }];
    if (option === questions[currentQ].correct) {
      return [styles.optionBtn, { backgroundColor: "#27AE6022", borderColor: "#27AE60" }];
    }
    if (option === selectedAnswer && option !== questions[currentQ].correct) {
      return [styles.optionBtn, { backgroundColor: "#E74C3C22", borderColor: "#E74C3C" }];
    }
    return [styles.optionBtn, { backgroundColor: colors.surface, borderColor: colors.border, opacity: 0.5 }];
  };

  const getOptionTextColor = (option: string) => {
    if (!selectedAnswer) return colors.foreground;
    if (option === questions[currentQ].correct) return "#27AE60";
    if (option === selectedAnswer) return "#E74C3C";
    return colors.muted;
  };

  if (quizState === "setup") {
    return (
      <ScreenContainer>
        <ScrollView contentContainerStyle={styles.setupContainer}>
          <Text style={[styles.setupTitle, { color: colors.foreground }]}>แบบทดสอบ</Text>
          <Text style={[styles.setupSub, { color: colors.muted }]}>เลือกระดับที่ต้องการทดสอบ</Text>

          {(["N3", "N2", "N1"] as const).map((lv) => (
            <Pressable
              key={lv}
              style={({ pressed }) => [
                styles.levelCard,
                { backgroundColor: colors.surface, borderColor: selectedLevel === lv ? LEVEL_COLORS[lv] : colors.border },
                selectedLevel === lv && { borderWidth: 2 },
                pressed && { opacity: 0.8 },
              ]}
              onPress={() => setSelectedLevel(lv)}
            >
              <View style={[styles.levelCardIcon, { backgroundColor: LEVEL_COLORS[lv] + "22" }]}>
                <Text style={[styles.levelCardText, { color: LEVEL_COLORS[lv] }]}>{lv}</Text>
              </View>
              <View style={styles.levelCardInfo}>
                <Text style={[styles.levelCardTitle, { color: colors.foreground }]}>
                  {lv === "N3" ? "ระดับกลาง" : lv === "N2" ? "ระดับสูง" : "ระดับสูงสุด"}
                </Text>
                <Text style={[styles.levelCardSub, { color: colors.muted }]}>
                  {lv === "N3" ? "เหมาะสำหรับผู้เริ่มต้น-กลาง" : lv === "N2" ? "เหมาะสำหรับระดับกลาง-สูง" : "เหมาะสำหรับผู้เชี่ยวชาญ"}
                </Text>
              </View>
              {selectedLevel === lv && (
                <IconSymbol name="checkmark.circle.fill" size={24} color={LEVEL_COLORS[lv]} />
              )}
            </Pressable>
          ))}

          <View style={[styles.quizInfo, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.quizInfoText, { color: colors.muted }]}>10 คำถาม • Multiple Choice • 4 ตัวเลือก</Text>
          </View>

          <Pressable
            style={({ pressed }) => [
              styles.startBtn,
              { backgroundColor: LEVEL_COLORS[selectedLevel] },
              pressed && { opacity: 0.85, transform: [{ scale: 0.97 }] },
            ]}
            onPress={startQuiz}
          >
            <IconSymbol name="checkmark.circle.fill" size={22} color="#FFFFFF" />
            <Text style={styles.startBtnText}>เริ่มทดสอบ</Text>
          </Pressable>
        </ScrollView>
      </ScreenContainer>
    );
  }

  if (quizState === "result") {
    const pct = Math.round((score / questions.length) * 100);
    const grade = pct >= 80 ? "ยอดเยี่ยม!" : pct >= 60 ? "ดีมาก!" : pct >= 40 ? "พอใช้" : "ต้องฝึกเพิ่ม";
    const gradeColor = pct >= 80 ? "#27AE60" : pct >= 60 ? "#F39C12" : pct >= 40 ? "#E67E22" : "#E74C3C";

    return (
      <ScreenContainer>
        <ScrollView contentContainerStyle={styles.resultContainer}>
          <View style={[styles.resultCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <IconSymbol name="trophy.fill" size={48} color="#F39C12" />
            <Text style={[styles.resultGrade, { color: gradeColor }]}>{grade}</Text>
            <Text style={[styles.resultScore, { color: colors.foreground }]}>
              {score} / {questions.length}
            </Text>
            <Text style={[styles.resultPct, { color: gradeColor }]}>{pct}%</Text>
            <View style={[styles.resultBarBg, { backgroundColor: colors.border }]}>
              <View style={[styles.resultBarFill, { width: `${pct}%` as any, backgroundColor: gradeColor }]} />
            </View>
            <Text style={[styles.resultLevel, { color: colors.muted }]}>ระดับ {selectedLevel}</Text>
          </View>

          <Pressable
            style={({ pressed }) => [
              styles.startBtn,
              { backgroundColor: LEVEL_COLORS[selectedLevel], marginTop: 24 },
              pressed && { opacity: 0.85, transform: [{ scale: 0.97 }] },
            ]}
            onPress={startQuiz}
          >
            <IconSymbol name="repeat" size={20} color="#FFFFFF" />
            <Text style={styles.startBtnText}>ทดสอบอีกครั้ง</Text>
          </Pressable>

          <Pressable
            style={({ pressed }) => [
              styles.outlineBtn,
              { borderColor: colors.border },
              pressed && { opacity: 0.8 },
            ]}
            onPress={() => setQuizState("setup")}
          >
            <Text style={[styles.outlineBtnText, { color: colors.foreground }]}>เลือกระดับใหม่</Text>
          </Pressable>
        </ScrollView>
      </ScreenContainer>
    );
  }

  const q = questions[currentQ];
  const progressPct = ((currentQ + 1) / questions.length) * 100;

  return (
    <ScreenContainer>
      <ScrollView contentContainerStyle={styles.quizContainer} showsVerticalScrollIndicator={false}>
        {/* Progress */}
        <View style={styles.quizProgress}>
          <Text style={[styles.quizCounter, { color: colors.muted }]}>
            {currentQ + 1} / {questions.length}
          </Text>
          <View style={[styles.quizBarBg, { backgroundColor: colors.border }]}>
            <View style={[styles.quizBarFill, { width: `${progressPct}%` as any, backgroundColor: LEVEL_COLORS[selectedLevel] }]} />
          </View>
          <Text style={[styles.quizScoreText, { color: colors.muted }]}>คะแนน: {score}</Text>
        </View>

        {/* Question */}
        <View style={[styles.questionCard, { backgroundColor: colors.surface, borderColor: colors.border }]}>
          <Text style={[styles.questionLabel, { color: colors.muted }]}>คำนี้หมายความว่าอะไร?</Text>
          <Text style={styles.questionKanji}>{q.question}</Text>
          <Text style={[styles.questionFurigana, { color: colors.muted }]}>{q.furigana}</Text>
        </View>

        {/* Options */}
        <View style={styles.optionsContainer}>
          {q.options.map((option, i) => (
            <Pressable
              key={i}
              style={({ pressed }) => [
                ...getOptionStyle(option),
                !selectedAnswer && pressed && { opacity: 0.8, transform: [{ scale: 0.98 }] },
              ]}
              onPress={() => handleAnswer(option)}
              disabled={!!selectedAnswer}
            >
              <Text style={[styles.optionLabel, { color: colors.muted }]}>
                {String.fromCharCode(65 + i)}.
              </Text>
              <Text style={[styles.optionText, { color: getOptionTextColor(option) }]}>
                {option}
              </Text>
              {selectedAnswer && option === q.correct && (
                <IconSymbol name="checkmark.circle.fill" size={20} color="#27AE60" />
              )}
              {selectedAnswer === option && option !== q.correct && (
                <IconSymbol name="xmark.circle.fill" size={20} color="#E74C3C" />
              )}
            </Pressable>
          ))}
        </View>

        {/* Explanation */}
        {showExplanation && (
          <View style={[styles.explanationBox, { backgroundColor: colors.surface, borderColor: colors.border }]}>
            <Text style={[styles.explanationTitle, { color: colors.muted }]}>คำอธิบาย</Text>
            <Text style={[styles.explanationText, { color: colors.foreground }]}>{q.explanation}</Text>
          </View>
        )}

        {/* Next Button */}
        {selectedAnswer && (
          <Pressable
            style={({ pressed }) => [
              styles.nextBtn,
              { backgroundColor: LEVEL_COLORS[selectedLevel] },
              pressed && { opacity: 0.85, transform: [{ scale: 0.97 }] },
            ]}
            onPress={handleNext}
          >
            <Text style={styles.nextBtnText}>
              {currentQ < questions.length - 1 ? "ถัดไป" : "ดูผลลัพธ์"}
            </Text>
            <IconSymbol name="arrow.right" size={20} color="#FFFFFF" />
          </Pressable>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  setupContainer: { padding: 20, paddingBottom: 40 },
  setupTitle: { fontSize: 26, fontWeight: "800", marginBottom: 6 },
  setupSub: { fontSize: 14, marginBottom: 24 },
  levelCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    borderRadius: 16,
    borderWidth: 1,
    marginBottom: 12,
    gap: 12,
  },
  levelCardIcon: {
    width: 52,
    height: 52,
    borderRadius: 14,
    alignItems: "center",
    justifyContent: "center",
  },
  levelCardText: { fontSize: 20, fontWeight: "900" },
  levelCardInfo: { flex: 1 },
  levelCardTitle: { fontSize: 16, fontWeight: "700" },
  levelCardSub: { fontSize: 12, marginTop: 2 },
  quizInfo: {
    padding: 12,
    borderRadius: 12,
    borderWidth: 1,
    alignItems: "center",
    marginBottom: 24,
  },
  quizInfoText: { fontSize: 13 },
  startBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 16,
    borderRadius: 16,
    gap: 8,
  },
  startBtnText: { color: "#FFFFFF", fontSize: 17, fontWeight: "700" },
  outlineBtn: {
    paddingVertical: 14,
    borderRadius: 16,
    borderWidth: 1,
    alignItems: "center",
    marginTop: 12,
  },
  outlineBtnText: { fontSize: 15, fontWeight: "600" },
  resultContainer: { padding: 20, paddingBottom: 40, alignItems: "center" },
  resultCard: {
    width: "100%",
    padding: 32,
    borderRadius: 24,
    borderWidth: 1,
    alignItems: "center",
    gap: 8,
  },
  resultGrade: { fontSize: 24, fontWeight: "800", marginTop: 8 },
  resultScore: { fontSize: 40, fontWeight: "900" },
  resultPct: { fontSize: 20, fontWeight: "700" },
  resultBarBg: { width: "100%", height: 10, borderRadius: 5, overflow: "hidden", marginTop: 8 },
  resultBarFill: { height: 10, borderRadius: 5 },
  resultLevel: { fontSize: 13, marginTop: 4 },
  quizContainer: { padding: 16, paddingBottom: 40 },
  quizProgress: { marginBottom: 16 },
  quizCounter: { fontSize: 13, marginBottom: 6 },
  quizBarBg: { height: 6, borderRadius: 3, overflow: "hidden", marginBottom: 6 },
  quizBarFill: { height: 6, borderRadius: 3 },
  quizScoreText: { fontSize: 13, textAlign: "right" },
  questionCard: {
    padding: 24,
    borderRadius: 20,
    borderWidth: 1,
    alignItems: "center",
    marginBottom: 20,
  },
  questionLabel: { fontSize: 13, marginBottom: 8 },
  questionKanji: { fontSize: 48, fontWeight: "900", color: "#C0392B" },
  questionFurigana: { fontSize: 16, marginTop: 6 },
  optionsContainer: { gap: 10, marginBottom: 16 },
  optionBtn: {
    flexDirection: "row",
    alignItems: "center",
    padding: 14,
    borderRadius: 14,
    borderWidth: 1,
    gap: 10,
  },
  optionLabel: { fontSize: 14, fontWeight: "700", width: 24 },
  optionText: { flex: 1, fontSize: 15, fontWeight: "500" },
  explanationBox: {
    padding: 14,
    borderRadius: 14,
    borderWidth: 1,
    marginBottom: 16,
  },
  explanationTitle: { fontSize: 12, fontWeight: "700", textTransform: "uppercase", letterSpacing: 1, marginBottom: 6 },
  explanationText: { fontSize: 14, lineHeight: 22 },
  nextBtn: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 16,
    borderRadius: 16,
    gap: 8,
  },
  nextBtnText: { color: "#FFFFFF", fontSize: 17, fontWeight: "700" },
});
