import { useState, useRef } from "react";
import {
  View,
  Text,
  Pressable,
  FlatList,
  StyleSheet,
  Animated,
  ScrollView,
} from "react-native";
import * as Haptics from "expo-haptics";
import { Platform } from "react-native";

import { ScreenContainer } from "@/components/screen-container";
import { useColors } from "@/hooks/use-colors";
import { useProgress } from "@/hooks/use-progress";
import { getVocabByLevel, VocabItem } from "@/data/vocabulary";
import { IconSymbol } from "@/components/ui/icon-symbol";

const LEVEL_COLORS = { N5: "#3498DB", N4: "#9B59B6", N3: "#27AE60", N2: "#E67E22", N1: "#C0392B" };

type Mode = "list" | "flashcard";

export default function VocabularyScreen() {
  const colors = useColors();
  const { progress, markLearned, isLearned } = useProgress();
  const [selectedLevel, setSelectedLevel] = useState<"N5" | "N4" | "N3" | "N2" | "N1">(progress.selectedLevel as "N5" | "N4" | "N3" | "N2" | "N1" || "N3");
  const [mode, setMode] = useState<Mode>("list");
  const [cardIndex, setCardIndex] = useState(0);
  const [showBack, setShowBack] = useState(false);
  const flipAnim = useRef(new Animated.Value(0)).current;

  const vocab = getVocabByLevel(selectedLevel);
  const unlearnedVocab = vocab.filter((v) => !isLearned(v.id || '', selectedLevel));
  const currentCard = unlearnedVocab[cardIndex] ?? vocab[cardIndex];

  const flipCard = () => {
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
    Animated.spring(flipAnim, {
      toValue: showBack ? 0 : 1,
      friction: 8,
      tension: 10,
      useNativeDriver: true,
    }).start();
    setShowBack(!showBack);
  };

  const frontInterpolate = flipAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ["0deg", "180deg"],
  });
  const backInterpolate = flipAnim.interpolate({
    inputRange: [0, 1],
    outputRange: ["180deg", "360deg"],
  });

  const handleKnow = async () => {
    if (!currentCard) return;
    if (Platform.OS !== "web") Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    await markLearned(currentCard.id || '', selectedLevel);
    setShowBack(false);
    flipAnim.setValue(0);
    if (cardIndex < unlearnedVocab.length - 1) {
      setCardIndex(cardIndex + 1);
    } else {
      setCardIndex(0);
    }
  };

  const handleDontKnow = () => {
    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Medium);
    setShowBack(false);
    flipAnim.setValue(0);
    if (cardIndex < (unlearnedVocab.length > 0 ? unlearnedVocab.length : vocab.length) - 1) {
      setCardIndex(cardIndex + 1);
    } else {
      setCardIndex(0);
    }
  };

  const renderVocabItem = ({ item }: { item: VocabItem }) => {
    const learned = isLearned(item.id || '', selectedLevel);
    return (
      <View
        style={[
          styles.vocabItem,
          { backgroundColor: colors.surface, borderColor: colors.border },
          learned && { borderLeftWidth: 4, borderLeftColor: LEVEL_COLORS[selectedLevel] },
        ]}
      >
        <View style={styles.vocabMain}>
          <Text style={[styles.vocabKanji, { color: colors.foreground }]}>{item.kanji}</Text>
          <Text style={[styles.vocabFurigana, { color: colors.muted }]}>{item.furigana}</Text>
          <Text style={[styles.vocabRomaji, { color: colors.muted }]}>{item.romaji}</Text>
        </View>
        <View style={styles.vocabRight}>
          <Text style={[styles.vocabMeaning, { color: colors.foreground }]}>{item.meaning}</Text>
          <View style={[styles.categoryBadge, { backgroundColor: colors.border }]}>
            <Text style={[styles.categoryText, { color: colors.muted }]}>{item.category}</Text>
          </View>
          {learned && (
            <View style={[styles.learnedBadge, { backgroundColor: LEVEL_COLORS[selectedLevel] + "22" }]}>
              <IconSymbol name="checkmark" size={12} color={LEVEL_COLORS[selectedLevel]} />
              <Text style={[styles.learnedText, { color: LEVEL_COLORS[selectedLevel] }]}>รู้แล้ว</Text>
            </View>
          )}
        </View>
      </View>
    );
  };

  return (
    <ScreenContainer>
      {/* Header */}
      <View style={[styles.header, { backgroundColor: colors.surface, borderBottomColor: colors.border }]}>
        <Text style={[styles.headerTitle, { color: colors.foreground }]}>คำศัพท์</Text>
        <View style={styles.levelTabs}>
          {(["N5", "N4", "N3", "N2", "N1"] as const).map((lv) => (
            <Pressable
              key={lv}
              style={({ pressed }) => [
                styles.levelTab,
                { borderColor: LEVEL_COLORS[lv] },
                selectedLevel === lv && { backgroundColor: LEVEL_COLORS[lv] },
                pressed && { opacity: 0.8 },
              ]}
              onPress={() => {
                setSelectedLevel(lv);
                setCardIndex(0);
                setShowBack(false);
                flipAnim.setValue(0);
              }}
            >
              <Text style={[styles.levelTabText, { color: selectedLevel === lv ? "#FFF" : LEVEL_COLORS[lv] }]}>
                {lv}
              </Text>
            </Pressable>
          ))}
        </View>
      </View>

      {/* Mode Toggle */}
      <View style={[styles.modeToggle, { backgroundColor: colors.border }]}>
        <Pressable
          style={[styles.modeBtn, mode === "list" && { backgroundColor: colors.surface }]}
          onPress={() => setMode("list")}
        >
          <Text style={[styles.modeBtnText, { color: mode === "list" ? colors.primary : colors.muted }]}>
            รายการ
          </Text>
        </Pressable>
        <Pressable
          style={[styles.modeBtn, mode === "flashcard" && { backgroundColor: colors.surface }]}
          onPress={() => setMode("flashcard")}
        >
          <Text style={[styles.modeBtnText, { color: mode === "flashcard" ? colors.primary : colors.muted }]}>
            Flashcard
          </Text>
        </Pressable>
      </View>

      {mode === "list" ? (
        <FlatList
          data={vocab}
          keyExtractor={(item, index) => item.id || `vocab-${index}`}
          renderItem={renderVocabItem}
          contentContainerStyle={{ padding: 12, paddingBottom: 24 }}
          showsVerticalScrollIndicator={false}
          ItemSeparatorComponent={() => <View style={{ height: 8 }} />}
        />
      ) : (
        <ScrollView contentContainerStyle={styles.flashcardContainer} showsVerticalScrollIndicator={false}>
          <Text style={[styles.cardCounter, { color: colors.muted }]}>
            {unlearnedVocab.length > 0
              ? `เหลือ ${unlearnedVocab.length} คำที่ยังไม่รู้`
              : "เรียนครบทุกคำแล้ว!"}
          </Text>

          {currentCard && (
            <Pressable onPress={flipCard} style={styles.cardWrapper}>
              {/* Front */}
              <Animated.View
                style={[
                  styles.card,
                  { backgroundColor: colors.surface, borderColor: colors.border },
                  { transform: [{ rotateY: frontInterpolate }] },
                  showBack && styles.cardHidden,
                ]}
              >
                <Text style={[styles.cardLevel, { color: LEVEL_COLORS[selectedLevel] }]}>
                  {currentCard.level}
                </Text>
                <Text style={styles.cardKanji}>{currentCard.kanji}</Text>
                <Text style={[styles.cardFurigana, { color: colors.muted }]}>{currentCard.furigana}</Text>
                <Text style={[styles.cardRomaji, { color: colors.muted }]}>{currentCard.romaji}</Text>
                <Pressable
                  onPress={() => {
                    // TODO: Add Text-to-Speech functionality
                    if (Platform.OS !== "web") Haptics.impactAsync(Haptics.ImpactFeedbackStyle.Light);
                  }}
                  style={({ pressed }) => [{ opacity: pressed ? 0.7 : 1 }]}
                >
                  <Text style={[styles.cardHint, { color: colors.primary }]}>🔊 ฟังเสียง</Text>
                </Pressable>
                <Text style={[styles.cardHint, { color: colors.muted }]}>แตะเพื่อดูความหมาย</Text>
              </Animated.View>

              {/* Back */}
              <Animated.View
                style={[
                  styles.card,
                  styles.cardBack,
                  { backgroundColor: LEVEL_COLORS[selectedLevel] + "15", borderColor: LEVEL_COLORS[selectedLevel] + "60" },
                  { transform: [{ rotateY: backInterpolate }] },
                  !showBack && styles.cardHidden,
                ]}
              >
                <Text style={[styles.cardLevel, { color: LEVEL_COLORS[selectedLevel] }]}>
                  {currentCard.level}
                </Text>
                <Text style={[styles.cardMeaning, { color: colors.foreground }]}>{currentCard.meaning}</Text>
                <View style={styles.exampleBox}>
                  <Text style={[styles.exampleJP, { color: colors.foreground }]}>{currentCard.exampleJP}</Text>
                  <Text style={[styles.exampleTH, { color: colors.muted }]}>{currentCard.exampleTH}</Text>
                </View>
              </Animated.View>
            </Pressable>
          )}

          {showBack && currentCard && (
            <View style={styles.actionRow}>
              <Pressable
                style={({ pressed }) => [
                  styles.actionBtn,
                  styles.dontKnowBtn,
                  pressed && { opacity: 0.8, transform: [{ scale: 0.97 }] },
                ]}
                onPress={handleDontKnow}
              >
                <IconSymbol name="xmark" size={20} color="#FFFFFF" />
                <Text style={styles.actionBtnText}>ยังไม่รู้</Text>
              </Pressable>
              <Pressable
                style={({ pressed }) => [
                  styles.actionBtn,
                  styles.knowBtn,
                  pressed && { opacity: 0.8, transform: [{ scale: 0.97 }] },
                ]}
                onPress={handleKnow}
              >
                <IconSymbol name="checkmark" size={20} color="#FFFFFF" />
                <Text style={styles.actionBtnText}>รู้แล้ว!</Text>
              </Pressable>
            </View>
          )}
        </ScrollView>
      )}
    </ScreenContainer>
  );
}

const styles = StyleSheet.create({
  header: {
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderBottomWidth: 0.5,
  },
  headerTitle: { fontSize: 22, fontWeight: "800", marginBottom: 10 },
  levelTabs: { flexDirection: "row", gap: 8 },
  levelTab: {
    paddingHorizontal: 16,
    paddingVertical: 6,
    borderRadius: 20,
    borderWidth: 2,
  },
  levelTabText: { fontSize: 13, fontWeight: "700" },
  modeToggle: {
    flexDirection: "row",
    margin: 12,
    borderRadius: 12,
    padding: 4,
  },
  modeBtn: {
    flex: 1,
    paddingVertical: 8,
    borderRadius: 10,
    alignItems: "center",
  },
  modeBtnText: { fontSize: 14, fontWeight: "600" },
  vocabItem: {
    flexDirection: "row",
    padding: 14,
    borderRadius: 14,
    borderWidth: 1,
    alignItems: "center",
  },
  vocabMain: { flex: 1 },
  vocabKanji: { fontSize: 22, fontWeight: "800" },
  vocabFurigana: { fontSize: 13, marginTop: 2 },
  vocabRomaji: { fontSize: 11, marginTop: 1 },
  vocabRight: { flex: 1, alignItems: "flex-end" },
  vocabMeaning: { fontSize: 15, fontWeight: "600", textAlign: "right" },
  categoryBadge: {
    marginTop: 4,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 8,
  },
  categoryText: { fontSize: 11 },
  learnedBadge: {
    flexDirection: "row",
    alignItems: "center",
    marginTop: 4,
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 8,
    gap: 4,
  },
  learnedText: { fontSize: 11, fontWeight: "600" },
  flashcardContainer: {
    alignItems: "center",
    padding: 16,
    paddingBottom: 40,
  },
  cardCounter: { fontSize: 13, marginBottom: 16 },
  cardWrapper: { width: "100%", aspectRatio: 0.75, maxHeight: 380 },
  card: {
    position: "absolute",
    width: "100%",
    height: "100%",
    borderRadius: 24,
    borderWidth: 1,
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
    backfaceVisibility: "hidden",
  },
  cardBack: { position: "absolute", width: "100%", height: "100%" },
  cardHidden: { opacity: 0 },
  cardLevel: { fontSize: 13, fontWeight: "700", marginBottom: 12, textTransform: "uppercase", letterSpacing: 2 },
  cardKanji: { fontSize: 52, fontWeight: "900", color: "#C0392B", textAlign: "center" },
  cardFurigana: { fontSize: 18, marginTop: 8, textAlign: "center" },
  cardRomaji: { fontSize: 14, marginTop: 4, textAlign: "center" },
  cardHint: { fontSize: 12, marginTop: 20 },
  cardMeaning: { fontSize: 32, fontWeight: "800", textAlign: "center" },
  exampleBox: { marginTop: 16, alignItems: "center", paddingHorizontal: 8 },
  exampleJP: { fontSize: 15, textAlign: "center", lineHeight: 22 },
  exampleTH: { fontSize: 13, textAlign: "center", marginTop: 6, lineHeight: 20 },
  actionRow: {
    flexDirection: "row",
    gap: 16,
    marginTop: 24,
    width: "100%",
  },
  actionBtn: {
    flex: 1,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 16,
    borderRadius: 16,
    gap: 8,
  },
  dontKnowBtn: { backgroundColor: "#E74C3C" },
  knowBtn: { backgroundColor: "#27AE60" },
  actionBtnText: { color: "#FFFFFF", fontSize: 16, fontWeight: "700" },
});
