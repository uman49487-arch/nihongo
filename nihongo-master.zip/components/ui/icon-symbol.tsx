// Fallback for using MaterialIcons on Android and web.

import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight, SymbolViewProps } from "expo-symbols";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type IconMapping = Record<SymbolViewProps["name"], ComponentProps<typeof MaterialIcons>["name"]>;
type IconSymbolName = keyof typeof MAPPING;

/**
 * SF Symbols to Material Icons mappings for Nihongo Master tabs and UI.
 */
const MAPPING = {
  // Tab icons
  "house.fill": "home",
  "book.fill": "menu-book",
  "text.book.closed.fill": "library-books",
  "checkmark.circle.fill": "quiz",
  "chart.bar.fill": "bar-chart",
  "gearshape.fill": "settings",
  // Navigation
  "paperplane.fill": "send",
  "chevron.left.forwardslash.chevron.right": "code",
  "chevron.right": "chevron-right",
  "chevron.left": "chevron-left",
  // Actions
  "arrow.clockwise": "refresh",
  "star.fill": "star",
  "heart.fill": "favorite",
  "xmark.circle.fill": "cancel",
  "checkmark": "check",
  "magnifyingglass": "search",
  "speaker.wave.2.fill": "volume-up",
  "flame.fill": "local-fire-department",
  "trophy.fill": "emoji-events",
  "clock.fill": "schedule",
  "person.fill": "person",
  "info.circle.fill": "info",
  "arrow.right": "arrow-forward",
  "arrow.left": "arrow-back",
  "xmark": "close",
  "plus": "add",
  "minus": "remove",
  "lock.fill": "lock",
  "lightbulb.fill": "lightbulb",
  "repeat": "repeat",
} as IconMapping;

/**
 * An icon component that uses native SF Symbols on iOS, and Material Icons on Android and web.
 */
export function IconSymbol({
  name,
  size = 24,
  color,
  style,
}: {
  name: IconSymbolName;
  size?: number;
  color: string | OpaqueColorValue;
  style?: StyleProp<TextStyle>;
  weight?: SymbolWeight;
}) {
  return <MaterialIcons color={color} size={size} name={MAPPING[name]} style={style} />;
}
