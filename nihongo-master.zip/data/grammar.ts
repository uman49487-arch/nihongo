export type GrammarItem = {
  id: string;
  pattern: string;
  meaning: string;
  usage: string;
  examples: { jp: string; th: string }[];
  level: "N3" | "N2" | "N1";
  category: string;
};

export const grammarN3: GrammarItem[] = [
  {
    id: "n3-g001",
    pattern: "〜ために",
    meaning: "เพื่อ... (แสดงจุดประสงค์)",
    usage: "動詞辞書形 + ために",
    examples: [
      { jp: "日本語を勉強するために、毎日練習します。", th: "เพื่อเรียนภาษาญี่ปุ่น ฉันฝึกทุกวัน" },
      { jp: "健康のために運動します。", th: "ออกกำลังกายเพื่อสุขภาพ" },
    ],
    level: "N3",
    category: "จุดประสงค์",
  },
  {
    id: "n3-g002",
    pattern: "〜ながら",
    meaning: "ขณะที่... / ในขณะเดียวกัน",
    usage: "動詞ます形(去ます) + ながら",
    examples: [
      { jp: "音楽を聴きながら勉強します。", th: "เรียนหนังสือขณะฟังเพลง" },
      { jp: "歩きながら電話します。", th: "โทรศัพท์ขณะเดิน" },
    ],
    level: "N3",
    category: "การกระทำพร้อมกัน",
  },
  {
    id: "n3-g003",
    pattern: "〜ても",
    meaning: "แม้ว่า... / ถึงแม้...",
    usage: "動詞て形 + も",
    examples: [
      { jp: "雨が降っても、行きます。", th: "แม้ฝนตก ก็จะไป" },
      { jp: "疲れていても、仕事を続けます。", th: "แม้เหนื่อย ก็ทำงานต่อ" },
    ],
    level: "N3",
    category: "เงื่อนไข",
  },
  {
    id: "n3-g004",
    pattern: "〜ようになる",
    meaning: "กลายเป็น... / เริ่มที่จะ...",
    usage: "動詞辞書形/ない形 + ようになる",
    examples: [
      { jp: "日本語が話せるようになりました。", th: "สามารถพูดภาษาญี่ปุ่นได้แล้ว" },
      { jp: "早く起きられるようになりました。", th: "ตื่นเช้าได้แล้ว" },
    ],
    level: "N3",
    category: "การเปลี่ยนแปลง",
  },
  {
    id: "n3-g005",
    pattern: "〜てしまう",
    meaning: "ทำ...จนเสร็จ / ทำ...โดยไม่ตั้งใจ",
    usage: "動詞て形 + しまう",
    examples: [
      { jp: "宿題をやってしまいました。", th: "ทำการบ้านเสร็จแล้ว" },
      { jp: "財布を忘れてしまいました。", th: "ลืมกระเป๋าสตางค์โดยไม่ตั้งใจ" },
    ],
    level: "N3",
    category: "การกระทำสมบูรณ์",
  },
  {
    id: "n3-g006",
    pattern: "〜はずだ",
    meaning: "น่าจะ... / ควรจะ...",
    usage: "動詞普通形 + はずだ",
    examples: [
      { jp: "彼はもう来るはずです。", th: "เขาน่าจะมาแล้ว" },
      { jp: "この店は安いはずです。", th: "ร้านนี้น่าจะถูก" },
    ],
    level: "N3",
    category: "การคาดเดา",
  },
  {
    id: "n3-g007",
    pattern: "〜かもしれない",
    meaning: "อาจจะ...",
    usage: "動詞普通形 + かもしれない",
    examples: [
      { jp: "明日雨が降るかもしれません。", th: "พรุ่งนี้อาจจะฝนตก" },
      { jp: "彼女は知っているかもしれません。", th: "เธออาจจะรู้" },
    ],
    level: "N3",
    category: "การคาดเดา",
  },
  {
    id: "n3-g008",
    pattern: "〜ことがある",
    meaning: "บางครั้ง... / เคย...",
    usage: "動詞辞書形 + ことがある",
    examples: [
      { jp: "遅刻することがあります。", th: "บางครั้งก็สาย" },
      { jp: "日本に行ったことがあります。", th: "เคยไปญี่ปุ่น" },
    ],
    level: "N3",
    category: "ประสบการณ์",
  },
];

export const grammarN2: GrammarItem[] = [
  {
    id: "n2-g001",
    pattern: "〜に対して",
    meaning: "ต่อ... / เกี่ยวกับ...",
    usage: "名詞 + に対して",
    examples: [
      { jp: "子供に対して優しくしてください。", th: "กรุณาใจดีต่อเด็ก" },
      { jp: "この問題に対して意見があります。", th: "มีความคิดเห็นเกี่ยวกับปัญหานี้" },
    ],
    level: "N2",
    category: "ความสัมพันธ์",
  },
  {
    id: "n2-g002",
    pattern: "〜によって",
    meaning: "ขึ้นอยู่กับ... / โดย...",
    usage: "名詞 + によって",
    examples: [
      { jp: "人によって考え方が違います。", th: "ความคิดแตกต่างกันขึ้นอยู่กับคน" },
      { jp: "この建物は有名な建築家によって設計されました。", th: "อาคารนี้ถูกออกแบบโดยสถาปนิกชื่อดัง" },
    ],
    level: "N2",
    category: "สาเหตุ/วิธีการ",
  },
  {
    id: "n2-g003",
    pattern: "〜にもかかわらず",
    meaning: "ทั้งๆ ที่... / แม้ว่า...",
    usage: "動詞普通形/名詞 + にもかかわらず",
    examples: [
      { jp: "雨にもかかわらず、試合を続けました。", th: "ทั้งๆ ที่ฝนตก ก็เล่นต่อ" },
      { jp: "努力したにもかかわらず、失敗しました。", th: "ทั้งๆ ที่พยายาม ก็ล้มเหลว" },
    ],
    level: "N2",
    category: "เงื่อนไขขัดแย้ง",
  },
  {
    id: "n2-g004",
    pattern: "〜わけだ",
    meaning: "นั่นแสดงว่า... / ก็คือ...",
    usage: "動詞普通形 + わけだ",
    examples: [
      { jp: "10年勉強したわけだから、上手なわけだ。", th: "เรียนมา 10 ปี ก็เก่งเป็นธรรมดา" },
      { jp: "彼は外国人だから、日本語が難しいわけだ。", th: "เขาเป็นชาวต่างชาติ ภาษาญี่ปุ่นก็ยากเป็นธรรมดา" },
    ],
    level: "N2",
    category: "การอธิบาย",
  },
  {
    id: "n2-g005",
    pattern: "〜に加えて",
    meaning: "นอกจาก... ยังมี...",
    usage: "名詞 + に加えて",
    examples: [
      { jp: "英語に加えて、中国語も話せます。", th: "นอกจากภาษาอังกฤษ ยังพูดภาษาจีนได้ด้วย" },
      { jp: "雨に加えて、風も強いです。", th: "นอกจากฝน ลมก็แรงด้วย" },
    ],
    level: "N2",
    category: "การเพิ่มเติม",
  },
  {
    id: "n2-g006",
    pattern: "〜ことから",
    meaning: "จากการที่... / เนื่องจาก...",
    usage: "動詞普通形 + ことから",
    examples: [
      { jp: "彼女が泣いていることから、何か悲しいことがあったと思います。", th: "จากการที่เธอร้องไห้ คิดว่ามีเรื่องเศร้า" },
    ],
    level: "N2",
    category: "สาเหตุ",
  },
];

export const grammarN1: GrammarItem[] = [
  {
    id: "n1-g001",
    pattern: "〜に即して",
    meaning: "ตามแนวทาง... / สอดคล้องกับ...",
    usage: "名詞 + に即して",
    examples: [
      { jp: "規則に即して行動してください。", th: "กรุณาปฏิบัติตามกฎ" },
      { jp: "現実に即した計画を立てます。", th: "วางแผนที่สอดคล้องกับความเป็นจริง" },
    ],
    level: "N1",
    category: "ความสอดคล้อง",
  },
  {
    id: "n1-g002",
    pattern: "〜をもって",
    meaning: "ด้วย... / โดย...",
    usage: "名詞 + をもって",
    examples: [
      { jp: "本日をもって退職します。", th: "ลาออกตั้งแต่วันนี้เป็นต้นไป" },
      { jp: "誠意をもって対応します。", th: "จะรับมือด้วยความจริงใจ" },
    ],
    level: "N1",
    category: "วิธีการ",
  },
  {
    id: "n1-g003",
    pattern: "〜ならではの",
    meaning: "เป็นเอกลักษณ์ของ... / เฉพาะของ...",
    usage: "名詞 + ならではの",
    examples: [
      { jp: "日本ならではの文化があります。", th: "มีวัฒนธรรมที่เป็นเอกลักษณ์ของญี่ปุ่น" },
      { jp: "職人ならではの技術です。", th: "เป็นทักษะที่เป็นเอกลักษณ์ของช่างฝีมือ" },
    ],
    level: "N1",
    category: "ลักษณะเฉพาะ",
  },
  {
    id: "n1-g004",
    pattern: "〜いかんによらず",
    meaning: "ไม่ว่า... จะเป็นอย่างไร",
    usage: "名詞 + いかんによらず",
    examples: [
      { jp: "理由のいかんによらず、遅刻は許されません。", th: "ไม่ว่าเหตุผลจะเป็นอย่างไร การมาสายไม่ได้รับอนุญาต" },
    ],
    level: "N1",
    category: "เงื่อนไข",
  },
  {
    id: "n1-g005",
    pattern: "〜に至っては",
    meaning: "ถึงขนาด... / ยิ่งไปกว่านั้น...",
    usage: "名詞 + に至っては",
    examples: [
      { jp: "彼に至っては、全く勉強しなかった。", th: "ถึงขนาดเขาไม่เรียนเลย" },
    ],
    level: "N1",
    category: "การเน้นย้ำ",
  },
];

// Import common grammar data (frequently used in daily life and JLPT)
import { grammarN3Common } from './grammar-n3-common';
import { grammarN2Common } from './grammar-n2-common';
import { grammarN1Common } from './grammar-n1-common';

// Use common grammar patterns only
export const allGrammar: GrammarItem[] = [
  ...grammarN3,
  ...grammarN2,
  ...grammarN1,
  ...(grammarN3Common as any),
  ...(grammarN2Common as any),
  ...(grammarN1Common as any),
];

export function getGrammarByLevel(level: "N3" | "N2" | "N1"): GrammarItem[] {
  return allGrammar.filter((g) => g.level === level);
}
