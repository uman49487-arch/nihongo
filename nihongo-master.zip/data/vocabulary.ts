import { vocabularyN3Expanded } from './vocabulary-n3-expanded';
import { vocabularyN2Expanded } from './vocabulary-n2-expanded';
import { vocabularyN1Expanded } from './vocabulary-n1-expanded';
import { vocabularyN4 as vocabularyN4Data } from './vocabulary-n4-expanded';
import { vocabularyN5 as vocabularyN5Data } from './vocabulary-n5-expanded';

export type VocabItem = {
  id?: string;
  kanji: string;
  furigana: string;
  romaji?: string;
  meaning: string;
  exampleJP?: string;
  example?: string;
  exampleTH: string;
  level?: "N5" | "N4" | "N3" | "N2" | "N1";
  category?: string;
};

export const vocabularyN3: VocabItem[] = vocabularyN3Expanded as VocabItem[];

export const vocabularyN3_OLD: VocabItem[] = [
  { id: "n3-001", kanji: "会議", furigana: "かいぎ", romaji: "kaigi", meaning: "การประชุม", exampleJP: "今日は会議があります。", exampleTH: "วันนี้มีการประชุม", level: "N3", category: "ธุรกิจ" },
  { id: "n3-002", kanji: "計画", furigana: "けいかく", romaji: "keikaku", meaning: "แผนการ", exampleJP: "旅行の計画を立てました。", exampleTH: "วางแผนการเดินทางแล้ว", level: "N3", category: "ทั่วไป" },
  { id: "n3-003", kanji: "経験", furigana: "けいけん", romaji: "keiken", meaning: "ประสบการณ์", exampleJP: "海外での経験が役に立ちます。", exampleTH: "ประสบการณ์ในต่างประเทศมีประโยชน์", level: "N3", category: "ทั่วไป" },
  { id: "n3-004", kanji: "研究", furigana: "けんきゅう", romaji: "kenkyuu", meaning: "การวิจัย", exampleJP: "大学で研究しています。", exampleTH: "กำลังทำวิจัยที่มหาวิทยาลัย", level: "N3", category: "การศึกษา" },
  { id: "n3-005", kanji: "準備", furigana: "じゅんび", romaji: "junbi", meaning: "การเตรียมพร้อม", exampleJP: "試験の準備をしています。", exampleTH: "กำลังเตรียมตัวสอบ", level: "N3", category: "ทั่วไป" },
  { id: "n3-006", kanji: "説明", furigana: "せつめい", romaji: "setsumei", meaning: "การอธิบาย", exampleJP: "先生が説明してくれました。", exampleTH: "อาจารย์อธิบายให้ฟัง", level: "N3", category: "การศึกษา" },
  { id: "n3-007", kanji: "連絡", furigana: "れんらく", romaji: "renraku", meaning: "การติดต่อ", exampleJP: "後で連絡します。", exampleTH: "จะติดต่อทีหลัง", level: "N3", category: "การสื่อสาร" },
  { id: "n3-008", kanji: "確認", furigana: "かくにん", romaji: "kakunin", meaning: "การยืนยัน/ตรวจสอบ", exampleJP: "予約を確認してください。", exampleTH: "กรุณาตรวจสอบการจอง", level: "N3", category: "ธุรกิจ" },
  { id: "n3-009", kanji: "注意", furigana: "ちゅうい", romaji: "chuui", meaning: "ความระวัง/คำเตือน", exampleJP: "注意してください。", exampleTH: "กรุณาระวัง", level: "N3", category: "ทั่วไป" },
  { id: "n3-010", kanji: "問題", furigana: "もんだい", romaji: "mondai", meaning: "ปัญหา/คำถาม", exampleJP: "問題を解決しました。", exampleTH: "แก้ปัญหาได้แล้ว", level: "N3", category: "ทั่วไป" },
  { id: "n3-011", kanji: "意見", furigana: "いけん", romaji: "iken", meaning: "ความคิดเห็น", exampleJP: "あなたの意見を聞かせてください。", exampleTH: "ขอฟังความคิดเห็นของคุณ", level: "N3", category: "การสื่อสาร" },
  { id: "n3-012", kanji: "関係", furigana: "かんけい", romaji: "kankei", meaning: "ความสัมพันธ์", exampleJP: "二人の関係は良いです。", exampleTH: "ความสัมพันธ์ของทั้งสองดี", level: "N3", category: "ทั่วไป" },
  { id: "n3-013", kanji: "場合", furigana: "ばあい", romaji: "baai", meaning: "กรณี/สถานการณ์", exampleJP: "その場合はどうしますか。", exampleTH: "ในกรณีนั้นจะทำอย่างไร", level: "N3", category: "ทั่วไป" },
  { id: "n3-014", kanji: "理由", furigana: "りゆう", romaji: "riyuu", meaning: "เหตุผล", exampleJP: "理由を教えてください。", exampleTH: "กรุณาบอกเหตุผล", level: "N3", category: "ทั่วไป" },
  { id: "n3-015", kanji: "方法", furigana: "ほうほう", romaji: "houhou", meaning: "วิธีการ", exampleJP: "良い方法があります。", exampleTH: "มีวิธีที่ดี", level: "N3", category: "ทั่วไป" },
  { id: "n3-016", kanji: "目的", furigana: "もくてき", romaji: "mokuteki", meaning: "จุดประสงค์/เป้าหมาย", exampleJP: "旅行の目的は何ですか。", exampleTH: "จุดประสงค์ของการเดินทางคืออะไร", level: "N3", category: "ทั่วไป" },
  { id: "n3-017", kanji: "必要", furigana: "ひつよう", romaji: "hitsuyou", meaning: "จำเป็น", exampleJP: "パスポートが必要です。", exampleTH: "จำเป็นต้องมีพาสปอร์ต", level: "N3", category: "ทั่วไป" },
  { id: "n3-018", kanji: "可能", furigana: "かのう", romaji: "kanou", meaning: "เป็นไปได้", exampleJP: "それは可能ですか。", exampleTH: "สิ่งนั้นเป็นไปได้ไหม", level: "N3", category: "ทั่วไป" },
  { id: "n3-019", kanji: "重要", furigana: "じゅうよう", romaji: "juuyou", meaning: "สำคัญ", exampleJP: "これは重要な情報です。", exampleTH: "นี่คือข้อมูลสำคัญ", level: "N3", category: "ทั่วไป" },
  { id: "n3-020", kanji: "特別", furigana: "とくべつ", romaji: "tokubetsu", meaning: "พิเศษ", exampleJP: "今日は特別な日です。", exampleTH: "วันนี้เป็นวันพิเศษ", level: "N3", category: "ทั่วไป" },
];

export const vocabularyN2: VocabItem[] = vocabularyN2Expanded as VocabItem[];

export const vocabularyN2_OLD: VocabItem[] = [
  { id: "n2-001", kanji: "影響", furigana: "えいきょう", romaji: "eikyou", meaning: "อิทธิพล/ผลกระทบ", exampleJP: "気候変動は生活に影響を与えます。", exampleTH: "การเปลี่ยนแปลงสภาพอากาศส่งผลกระทบต่อชีวิต", level: "N2", category: "สังคม" },
  { id: "n2-002", kanji: "状況", furigana: "じょうきょう", romaji: "joukyou", meaning: "สถานการณ์", exampleJP: "現在の状況を説明します。", exampleTH: "จะอธิบายสถานการณ์ปัจจุบัน", level: "N2", category: "ทั่วไป" },
  { id: "n2-003", kanji: "判断", furigana: "はんだん", romaji: "handan", meaning: "การตัดสิน/วินิจฉัย", exampleJP: "自分で判断してください。", exampleTH: "กรุณาตัดสินใจด้วยตัวเอง", level: "N2", category: "ทั่วไป" },
  { id: "n2-004", kanji: "提案", furigana: "ていあん", romaji: "teian", meaning: "ข้อเสนอ", exampleJP: "新しい提案があります。", exampleTH: "มีข้อเสนอใหม่", level: "N2", category: "ธุรกิจ" },
  { id: "n2-005", kanji: "評価", furigana: "ひょうか", romaji: "hyouka", meaning: "การประเมิน/ชื่นชม", exampleJP: "仕事の評価が高いです。", exampleTH: "การประเมินงานสูง", level: "N2", category: "ธุรกิจ" },
  { id: "n2-006", kanji: "改善", furigana: "かいぜん", romaji: "kaizen", meaning: "การปรับปรุง", exampleJP: "システムを改善しました。", exampleTH: "ปรับปรุงระบบแล้ว", level: "N2", category: "ธุรกิจ" },
  { id: "n2-007", kanji: "促進", furigana: "そくしん", romaji: "sokushin", meaning: "การส่งเสริม/เร่งรัด", exampleJP: "経済成長を促進します。", exampleTH: "ส่งเสริมการเติบโตทางเศรษฐกิจ", level: "N2", category: "สังคม" },
  { id: "n2-008", kanji: "維持", furigana: "いじ", romaji: "iji", meaning: "การรักษา/คงไว้", exampleJP: "健康を維持することが大切です。", exampleTH: "การรักษาสุขภาพเป็นสิ่งสำคัญ", level: "N2", category: "สุขภาพ" },
  { id: "n2-009", kanji: "対応", furigana: "たいおう", romaji: "taiou", meaning: "การรับมือ/ตอบสนอง", exampleJP: "問題に対応しました。", exampleTH: "รับมือกับปัญหาแล้ว", level: "N2", category: "ธุรกิจ" },
  { id: "n2-010", kanji: "効果", furigana: "こうか", romaji: "kouka", meaning: "ผล/ประสิทธิภาพ", exampleJP: "この薬は効果があります。", exampleTH: "ยานี้มีผล", level: "N2", category: "สุขภาพ" },
  { id: "n2-011", kanji: "課題", furigana: "かだい", romaji: "kadai", meaning: "ปัญหา/ภารกิจ", exampleJP: "重要な課題を解決しました。", exampleTH: "แก้ปัญหาสำคัญได้แล้ว", level: "N2", category: "ทั่วไป" },
  { id: "n2-012", kanji: "背景", furigana: "はいけい", romaji: "haikei", meaning: "พื้นหลัง/บริบท", exampleJP: "事件の背景を調べました。", exampleTH: "สืบสวนพื้นหลังของเหตุการณ์", level: "N2", category: "ทั่วไป" },
  { id: "n2-013", kanji: "観点", furigana: "かんてん", romaji: "kanten", meaning: "มุมมอง/จุดยืน", exampleJP: "異なる観点から考えます。", exampleTH: "คิดจากมุมมองที่แตกต่าง", level: "N2", category: "ทั่วไป" },
  { id: "n2-014", kanji: "傾向", furigana: "けいこう", romaji: "keikou", meaning: "แนวโน้ม", exampleJP: "最近の傾向を分析します。", exampleTH: "วิเคราะห์แนวโน้มล่าสุด", level: "N2", category: "สังคม" },
  { id: "n2-015", kanji: "概念", furigana: "がいねん", romaji: "gainen", meaning: "แนวคิด/ความคิดรวบยอด", exampleJP: "この概念を理解しました。", exampleTH: "เข้าใจแนวคิดนี้แล้ว", level: "N2", category: "การศึกษา" },
];

export const vocabularyN1: VocabItem[] = vocabularyN1Expanded as VocabItem[];

export const vocabularyN4Expanded: VocabItem[] = vocabularyN4Data.map((v, i) => ({
  ...v,
  id: `n4-${String(i + 1).padStart(3, '0')}`,
  romaji: '',
  level: 'N4',
  category: 'ทั่วไป',
})) as VocabItem[];

export const vocabularyN5Expanded: VocabItem[] = vocabularyN5Data.map((v, i) => ({
  ...v,
  id: `n5-${String(i + 1).padStart(3, '0')}`,
  romaji: '',
  level: 'N5',
  category: 'ทั่วไป',
})) as VocabItem[];

export function getVocabByLevel(level: "N5" | "N4" | "N3" | "N2" | "N1"): VocabItem[] {
  switch (level) {
    case 'N5':
      return vocabularyN5Expanded;
    case 'N4':
      return vocabularyN4Expanded;
    case 'N3':
      return vocabularyN3;
    case 'N2':
      return vocabularyN2;
    case 'N1':
      return vocabularyN1;
    default:
      return vocabularyN3;
  }
}

// For backward compatibility
export function getVocabularyByLevel(level: "N5" | "N4" | "N3" | "N2" | "N1"): VocabItem[] {
  return getVocabByLevel(level);
}

export const vocabularyN1_OLD: VocabItem[] = [
  { id: "n1-001", kanji: "概括", furigana: "がいかつ", romaji: "gaikatsu", meaning: "การสรุปรวม", exampleJP: "内容を概括して説明します。", exampleTH: "จะอธิบายโดยสรุปเนื้อหา", level: "N1", category: "วิชาการ" },
  { id: "n1-002", kanji: "矛盾", furigana: "むじゅん", romaji: "mujun", meaning: "ความขัดแย้ง", exampleJP: "この説明には矛盾があります。", exampleTH: "คำอธิบายนี้มีความขัดแย้ง", level: "N1", category: "วิชาการ" },
  { id: "n1-003", kanji: "抽象", furigana: "ちゅうしょう", romaji: "chuushou", meaning: "นามธรรม", exampleJP: "抽象的な概念を理解する。", exampleTH: "ทำความเข้าใจแนวคิดนามธรรม", level: "N1", category: "วิชาการ" },
  { id: "n1-004", kanji: "具体", furigana: "ぐたい", romaji: "gutai", meaning: "รูปธรรม/เป็นรูปธรรม", exampleJP: "具体的な例を挙げてください。", exampleTH: "กรุณายกตัวอย่างที่เป็นรูปธรรม", level: "N1", category: "วิชาการ" },
  { id: "n1-005", kanji: "論理", furigana: "ろんり", romaji: "ronri", meaning: "ตรรกะ", exampleJP: "論理的に考えることが大切です。", exampleTH: "การคิดอย่างมีตรรกะเป็นสิ่งสำคัญ", level: "N1", category: "วิชาการ" },
  { id: "n1-006", kanji: "根拠", furigana: "こんきょ", romaji: "konkyo", meaning: "หลักฐาน/เหตุผลรองรับ", exampleJP: "根拠を示してください。", exampleTH: "กรุณาแสดงหลักฐาน", level: "N1", category: "วิชาการ" },
  { id: "n1-007", kanji: "仮説", furigana: "かせつ", romaji: "kasetsu", meaning: "สมมติฐาน", exampleJP: "仮説を立てて実験します。", exampleTH: "ตั้งสมมติฐานแล้วทดลอง", level: "N1", category: "วิทยาศาสตร์" },
  { id: "n1-008", kanji: "検証", furigana: "けんしょう", romaji: "kenshou", meaning: "การพิสูจน์/ตรวจสอบ", exampleJP: "理論を検証しました。", exampleTH: "พิสูจน์ทฤษฎีแล้ว", level: "N1", category: "วิทยาศาสตร์" },
  { id: "n1-009", kanji: "普遍", furigana: "ふへん", romaji: "fuhen", meaning: "สากล/ทั่วไป", exampleJP: "これは普遍的な真理です。", exampleTH: "นี่คือความจริงสากล", level: "N1", category: "วิชาการ" },
  { id: "n1-010", kanji: "本質", furigana: "ほんしつ", romaji: "honshitsu", meaning: "แก่นแท้/สาระสำคัญ", exampleJP: "問題の本質を見極めます。", exampleTH: "หาแก่นแท้ของปัญหา", level: "N1", category: "วิชาการ" },
  { id: "n1-011", kanji: "顕著", furigana: "けんちょ", romaji: "kencho", meaning: "โดดเด่น/ชัดเจน", exampleJP: "顕著な変化が見られます。", exampleTH: "เห็นการเปลี่ยนแปลงที่โดดเด่น", level: "N1", category: "ทั่วไป" },
  { id: "n1-012", kanji: "懸念", furigana: "けねん", romaji: "kenen", meaning: "ความกังวล", exampleJP: "安全に関する懸念があります。", exampleTH: "มีความกังวลเกี่ยวกับความปลอดภัย", level: "N1", category: "ทั่วไป" },
];

export const allVocabulary: VocabItem[] = [...vocabularyN5Expanded, ...vocabularyN4Expanded, ...vocabularyN3, ...vocabularyN2, ...vocabularyN1];
