# Nihongo Master — Design Document

## App Overview
แอปมือถือสำหรับเรียนภาษาญี่ปุ่นระดับ JLPT N1–N3 ครอบคลุมคำศัพท์ ไวยากรณ์ การอ่าน และแบบทดสอบ

---

## Brand Identity
- **App Name:** Nihongo Master
- **Tagline:** เรียนภาษาญี่ปุ่น N1–N3
- **Primary Color:** Deep Red `#C0392B` (สีแดงเข้มแบบญี่ปุ่น — torii gate)
- **Accent Color:** Gold `#F39C12`
- **Background Light:** `#FAFAFA`
- **Background Dark:** `#1A1A1A`
- **Surface Light:** `#FFFFFF`
- **Surface Dark:** `#242424`
- **Typography:** System font (San Francisco / Roboto)

---

## Screen List

### 1. Home Screen (`/`)
- ทักทายผู้ใช้ + แสดงระดับที่กำลังเรียน (N3/N2/N1)
- สรุปความก้าวหน้าวันนี้ (Daily Streak, คำที่เรียนแล้ว)
- Quick Action Cards: คำศัพท์วันนี้, ทบทวน, แบบทดสอบ
- Banner แสดงบทเรียนที่กำลังเรียนอยู่

### 2. Vocabulary Screen (`/vocabulary`)
- เลือกระดับ N3 / N2 / N1
- รายการคำศัพท์แบบ FlatList พร้อม Kanji, Furigana, ความหมาย
- ระบบ Flashcard แบบ Flip Animation
- ปุ่ม "รู้แล้ว / ยังไม่รู้" สำหรับ Spaced Repetition

### 3. Grammar Screen (`/grammar`)
- รายการไวยากรณ์ตามระดับ
- แต่ละรายการมี: โครงสร้าง, ความหมาย, ตัวอย่างประโยค (JP + TH)
- ค้นหาไวยากรณ์

### 4. Quiz Screen (`/quiz`)
- เลือกระดับและหมวดหมู่ (คำศัพท์ / ไวยากรณ์ / การอ่าน)
- แบบทดสอบ Multiple Choice 4 ตัวเลือก
- แสดงผลทันทีหลังตอบ (ถูก/ผิด + คำอธิบาย)
- สรุปคะแนนท้ายชุด

### 5. Progress Screen (`/progress`)
- Daily Streak Calendar
- กราฟความก้าวหน้า (คำศัพท์ที่เรียนแล้วแต่ละระดับ)
- สถิติ: คำทั้งหมด, คำที่เรียนแล้ว, คะแนนเฉลี่ย Quiz

### 6. Settings Screen (`/settings`)
- เลือกระดับเริ่มต้น (N3/N2/N1)
- Dark Mode Toggle
- รีเซ็ตความก้าวหน้า

---

## Key User Flows

### Flow 1: เรียนคำศัพท์ใหม่
Home → Vocabulary Tab → เลือกระดับ → Flashcard → ปุ่ม รู้แล้ว/ยังไม่รู้ → บันทึกความก้าวหน้า

### Flow 2: ทบทวนด้วย Quiz
Home → Quiz Tab → เลือกระดับ → ตอบคำถาม → ดูผล → กลับ Home

### Flow 3: ดูไวยากรณ์
Home → Grammar Tab → เลือกระดับ → ค้นหา/เลื่อนดู → อ่านรายละเอียด

### Flow 4: ดูความก้าวหน้า
Home → Progress Tab → ดู Streak + กราฟ + สถิติ

---

## Navigation Structure
- **Bottom Tab Bar** (5 tabs):
  1. 🏠 Home
  2. 📖 คำศัพท์ (Vocabulary)
  3. ✏️ ไวยากรณ์ (Grammar)
  4. 🎯 ทดสอบ (Quiz)
  5. 📊 ความก้าวหน้า (Progress)

---

## Component Design Principles
- Cards ใช้ `rounded-2xl` + `shadow-sm` + `border border-border`
- Buttons หลัก: `bg-primary rounded-full` + scale feedback
- Level Badge: `N3` = สีเขียว, `N2` = สีส้ม, `N1` = สีแดง
- Flashcard: Flip animation 3D ด้วย react-native-reanimated
- Progress Bar: animated fill ด้วย Reanimated
