import AsyncStorage from "@react-native-async-storage/async-storage";
import { useCallback, useEffect, useState } from "react";

export type LevelProgress = {
  learned: string[]; // vocab/grammar IDs
  quizScores: { date: string; score: number; total: number; level: string }[];
};

export type AppProgress = {
  selectedLevel: "N5" | "N4" | "N3" | "N2" | "N1";
  streak: number;
  lastStudyDate: string;
  n5: LevelProgress;
  n4: LevelProgress;
  n3: LevelProgress;
  n2: LevelProgress;
  n1: LevelProgress;
};

const DEFAULT_PROGRESS: AppProgress = {
  selectedLevel: "N3",
  streak: 0,
  lastStudyDate: "",
  n5: { learned: [], quizScores: [] },
  n4: { learned: [], quizScores: [] },
  n3: { learned: [], quizScores: [] },
  n2: { learned: [], quizScores: [] },
  n1: { learned: [], quizScores: [] },
};

const STORAGE_KEY = "nihongo_progress";

export function useProgress() {
  const [progress, setProgress] = useState<AppProgress>(DEFAULT_PROGRESS);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadProgress();
  }, []);

  const loadProgress = async () => {
    try {
      const stored = await AsyncStorage.getItem(STORAGE_KEY);
      if (stored) {
        setProgress(JSON.parse(stored));
      }
    } catch (e) {
      console.error("Failed to load progress", e);
    } finally {
      setLoading(false);
    }
  };

  const saveProgress = async (newProgress: AppProgress) => {
    try {
      await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(newProgress));
      setProgress(newProgress);
    } catch (e) {
      console.error("Failed to save progress", e);
    }
  };

  const markLearned = useCallback(
    async (id: string, level: "N3" | "N2" | "N1") => {
      const key = level.toLowerCase() as "n3" | "n2" | "n1";
      const levelData = progress[key];
      if (levelData.learned.includes(id)) return;

      const today = new Date().toISOString().split("T")[0];
      const newStreak =
        progress.lastStudyDate === today
          ? progress.streak
          : progress.lastStudyDate === getPreviousDay(today)
          ? progress.streak + 1
          : 1;

      const newProgress: AppProgress = {
        ...progress,
        streak: newStreak,
        lastStudyDate: today,
        [key]: { ...levelData, learned: [...levelData.learned, id] },
      };
      await saveProgress(newProgress);
    },
    [progress]
  );

  const addQuizScore = useCallback(
    async (score: number, total: number, level: "N3" | "N2" | "N1") => {
      const key = level.toLowerCase() as "n3" | "n2" | "n1";
      const levelData = progress[key];
      const today = new Date().toISOString().split("T")[0];
      const newProgress: AppProgress = {
        ...progress,
        [key]: {
          ...levelData,
          quizScores: [
            ...levelData.quizScores,
            { date: today, score, total, level },
          ],
        },
      };
      await saveProgress(newProgress);
    },
    [progress]
  );

  const setSelectedLevel = useCallback(
    async (level: "N3" | "N2" | "N1") => {
      const newProgress = { ...progress, selectedLevel: level };
      await saveProgress(newProgress);
    },
    [progress]
  );

  const resetProgress = useCallback(async () => {
    await saveProgress(DEFAULT_PROGRESS);
  }, []);

  const getLearnedCount = (level: "N3" | "N2" | "N1") => {
    const key = level.toLowerCase() as "n3" | "n2" | "n1";
    return progress[key].learned.length;
  };

  const isLearned = (id: string, level: "N3" | "N2" | "N1") => {
    const key = level.toLowerCase() as "n3" | "n2" | "n1";
    return progress[key].learned.includes(id);
  };

  const getAverageQuizScore = (level: "N3" | "N2" | "N1") => {
    const key = level.toLowerCase() as "n3" | "n2" | "n1";
    const scores = progress[key].quizScores;
    if (scores.length === 0) return 0;
    const total = scores.reduce((sum, s) => sum + (s.score / s.total) * 100, 0);
    return Math.round(total / scores.length);
  };

  return {
    progress,
    loading,
    markLearned,
    addQuizScore,
    setSelectedLevel,
    resetProgress,
    getLearnedCount,
    isLearned,
    getAverageQuizScore,
  };
}

function getPreviousDay(dateStr: string): string {
  const date = new Date(dateStr);
  date.setDate(date.getDate() - 1);
  return date.toISOString().split("T")[0];
}
