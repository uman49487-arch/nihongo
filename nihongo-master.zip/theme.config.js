/** @type {const} */
const themeColors = {
  primary: { light: '#C0392B', dark: '#E74C3C' },
  background: { light: '#FAFAFA', dark: '#1A1A1A' },
  surface: { light: '#FFFFFF', dark: '#242424' },
  foreground: { light: '#1A1A1A', dark: '#F5F5F5' },
  muted: { light: '#6B7280', dark: '#9CA3AF' },
  border: { light: '#E5E7EB', dark: '#374151' },
  success: { light: '#27AE60', dark: '#2ECC71' },
  warning: { light: '#F39C12', dark: '#F1C40F' },
  error: { light: '#C0392B', dark: '#E74C3C' },
  accent: { light: '#F39C12', dark: '#F1C40F' },
  n3color: { light: '#27AE60', dark: '#2ECC71' },
  n2color: { light: '#E67E22', dark: '#F39C12' },
  n1color: { light: '#C0392B', dark: '#E74C3C' },
};

module.exports = { themeColors };
